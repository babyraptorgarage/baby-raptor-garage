RR Garage v1.1 — Ranger Raptor only.
Open index.html in a browser for a local preview. For reliable iPhone Home Screen installation, host the folder over HTTPS.
Data is stored in localStorage; export JSON backups. This is a personal prototype, not yet a multi-user cloud app.
Existing v1 browser data is preserved because the same storage key is used.
